﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace NumberGuesser
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Number Guesser!");
            Console.WriteLine("Choose a difficulty level:");
            Console.WriteLine("1. Easy (1-50)");
            Console.WriteLine("2. Medium (1-100)");
            Console.WriteLine("3. Hard (1-500)");

            string input = Console.ReadLine();
            int maxNumber = 0;

            switch (input)
            {
                case "1":
                    maxNumber = 50;
                    break;
                case "2":
                    maxNumber = 100;
                    break;
                case "3":
                    maxNumber = 500;
                    break;
                default:
                    Console.WriteLine("Invalid input. Please try again.");
                    break;
            }

            if (maxNumber > 0)
            {
                Random random = new Random();
                int numberToGuess = random.Next(1, maxNumber + 1);
                int numAttempts = 0;
                bool guessedCorrectly = false;
                Stopwatch stopwatch = new Stopwatch();

                while (!guessedCorrectly)
                {
                    Console.Write("Enter your guess: ");
                    string guessInput = Console.ReadLine();

                    if (int.TryParse(guessInput, out int guess))
                    {
                        numAttempts++;
                        stopwatch.Stop();
                        TimeSpan elapsedTime = stopwatch.Elapsed;

                        if (guess < numberToGuess)
                        {
                            Console.WriteLine("Too low. Try again.");
                            Console.WriteLine($"Elapsed time: {elapsedTime.Seconds} seconds");
                            stopwatch.Start();
                        }
                        else if (guess > numberToGuess)
                        {
                            Console.WriteLine("Too high. Try again.");
                            Console.WriteLine($"Elapsed time: {elapsedTime.Seconds} seconds");
                            stopwatch.Start();
                        }
                        else
                        {
                            Console.WriteLine($"Congratulations! You guessed the number in {numAttempts} attempts.");
                            Console.WriteLine($"Elapsed time: {elapsedTime.Seconds} seconds");
                            guessedCorrectly = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a number.");
                    }
                }

                List<int> highScores = new List<int>();
                highScores.Add(numAttempts);
                highScores.Sort();

                if (highScores.Count > 10)
                {
                    highScores.RemoveAt(0);
                }

                Console.WriteLine("High scores:");
                foreach (int score in highScores)
                {
                    Console.WriteLine(score);
                }
            }

            Console.WriteLine("Thanks for playing!");
            Console.ReadLine();
        }
    }
}
