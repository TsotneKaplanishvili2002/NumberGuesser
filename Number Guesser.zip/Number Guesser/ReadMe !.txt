Project Title: Number Guesser

Project Description:
program generates a random number between 1 and 100, and the user has to guess that number. The program should give feedback to the user if their guess is too high or too low, and keep track of the number of attempts it took for the user to guess the correct number.


ქართულად: 
პროექტის სახელწოდება: Number Guesser

პროექტის აღწერა:
პროგრამა წარმოქმნის შემთხვევით რიცხვს 1-დან 100-მდე და მომხმარებელმა უნდა გამოიცნოს ეს რიცხვი. პროგრამამ უნდა მიაწოდოს უკუკავშირი მომხმარებელს, თუ მათი გამოცნობილი ნაკლებია პროგრამისგან არჩეულ რიცხვზე დაწეროს რომ ეს დაბალია ხოლო თუ პირიქით დაწეროს რომ რიცხვს აცდა, და თვალყური ადევნოს მომხმარებელმა მცდელობების რაოდენობას სწორი რიცხვის გამოცნობისთვის. ასევე პროგრამა ითვლის დროს თუ რა დრო დაგჭირდებათ რომ იპოვოთ სწორი პროგრამისგან არჩეული რიცხვი.